#!/usr/bin/MathematicaScript -script

Options[legendMaker] = Join[FilterRules[Options[Framed], Except[{ImageSize, FrameStyle, Background, RoundingRadius, ImageMargins}]], {FrameStyle -> None, Background -> Directive[Opacity[0.7], LightGray], RoundingRadius -> 10, ImageMargins -> 0, PlotStyle -> Automatic, PlotMarkers -> None, "LegendLineWidth" -> 35, "LegendLineAspectRatio" -> 0.3, "LegendMarkerSize" -> 8, "LegendGridOptions" -> {Alignment -> Left, Spacings -> {0.4, 0.1}}}];
legendMaker[textLabels_, opts : OptionsPattern[]] := Module[{f, lineDirectives, markerSymbols, n = Length[textLabels], x}, lineDirectives = PlotStyle /. {opts} /. PlotStyle | Automatic :> ColorData[1] /@ Range[n] /. None -> {None};
 markerSymbols = Replace[PlotMarkers /. {opts} /. Automatic :> (Drop[ListPlot[Transpose[{Range[n]}], PlotMarkers -> Automatic][[1, 2]][[1]], -1] /. Inset[x_, i__] :> x)[[All, -1]] /. {Graphics[gr__], sc_} :> Graphics[gr, ImageSize -> ("LegendMarkerSize" /. {opts} /. Options[legendMaker, "LegendMarkerSize"] /. {"LegendMarkerSize" -> 8})], PlotMarkers | None :> (Style["", Opacity[0]] & ) /@ textLabels] /. None | {} -> Style["", Opacity[0]];
 lineDirectives = PadRight[lineDirectives, n, lineDirectives];
 markerSymbols = PadRight[markerSymbols, n, markerSymbols];
 f = Grid[MapThread[{Graphics[{#1 /. None -> {}, If[#1 === {None} || (PlotStyle /. {opts}) === None, {}, Line[{{-0.1, 0}, {0.1, 0}}]], Inset[#2, {0, 0}, Background -> None]}, AspectRatio -> ("LegendLineAspectRatio" /. {opts} /. Options[legendMaker, "LegendLineAspectRatio"] /. {"LegendLineAspectRatio" -> 0.2}), ImageSize -> ("LegendLineWidth" /. {opts} /. Options[legendMaker, "LegendLineWidth"] /. {"LegendLineWidth" -> 35}), ImagePadding -> {{1, 1}, {0, 0}}], Text[#3, FormatType -> TraditionalForm]} & , {lineDirectives, markerSymbols, textLabels}], Sequence[Evaluate["LegendGridOptions" /. {opts} /. Options[legendMaker, "LegendGridOptions"] /. {"LegendGridOptions" -> {Alignment -> Left, Spacings -> {0.4, 0.1}}}]]];
 Framed[f, FilterRules[{Sequence[opts, Options[legendMaker]]}, FilterRules[Options[Framed], Except[ImageSize]]]]];
 extractStyles[plot_] := Module[{lines, markers, extract = First[Normal[plot]]}, lines = Select[extract, FreeQ[#1, Inset] & ];
 markers = Select[extract,  ! FreeQ[#1, Inset] & ];
 {Replace[Cases[lines, {c__, Line[__], ___} :> Flatten[Directive @@ Cases[{c}, Except[_Line]]], Infinity], {} -> None], Replace[Join[Cases[markers, {c__, Inset[s_, pos_, d___], e___} :> If[Head[s] === Graphics, {s, Last[{0.01, d}] /. Scaled[f_] :> First[f]}, If[FreeQ[s, CMYKColor | RGBColor | GrayLevel | Hue], Style[s, c], s]], Infinity], Cases[lines, {c___, PointSize[_], d___, Point[pt__], ___} :> {Graphics[{c, d, Point[{0, 0}]}], 0.01}, Infinity]], {} -> None]}] Options[autoLegend] = {Alignment -> {Right, Top}, Background -> White, AspectRatio -> Automatic};
 autoLegend[plot_Graphics, labels_, opts : OptionsPattern[]] := Module[{lines, markers, align = OptionValue[Alignment]}, {lines, markers} = extractStyles[plot];
 Graphics[{Inset[plot, {-1, -1}, {Left, Bottom}, Scaled[1]], Inset[legendMaker[labels, PlotStyle -> lines, PlotMarkers -> markers, opts], align, (If[NumericQ[#1], Center, #1] & ) /@ align]}, PlotRange -> {{-1, 1}, {-1, 1}}, AspectRatio -> (OptionValue[AspectRatio] /. Automatic :> (AspectRatio /. Options[plot, AspectRatio]) /. Automatic :> (AspectRatio /. AbsoluteOptions[plot, AspectRatio]))]];
                               
dataDir1 = 
  StringJoin[$HomeDirectory, 
   "/Git-Projects/emacs-archive-tracker/"]; 
leg = {"Total", "Gnu", "Marmalade", "Melpa"}; 
outPlotFileName := "full-plot.jpg"; 
importWithDate[
   n_Integer] := ({DateList[{#1[[1]], {"Year", "-", "Month", "-", 
         "Day", "T", "Hour", ":", "Minute"}}], #1[[2]]} & ) /@ 
       Import[
    StringJoin[dataDir1, "main-dish.dat"], {"Data", "All", {2, n}}]; 
totalCount = importWithDate[3]; 
singleCount = importWithDate[4]; 
tarCount = importWithDate[5]; 
gnuCount = importWithDate[6]; 
marmaladeCount = importWithDate[7]; 
melpaCount = importWithDate[8]; 
countToGrowth[list_, date_] := 
  Module[{iv = 
     Drop[list, (Position[#1, 
            First[Nearest[#1, AbsoluteTime[date]]]] & )[
         AbsoluteTime /@ list[[All, 1]]][[1, 1]] - 1]}, 
       ({#1[[1]], #1[[2]] - iv[[1, 2]]} & ) /@ iv]; 
today = Take[DateList[], 3]; 
growthPlot[rs_, 
   re_: today] := (Overlay[{#1, legendMaker[leg]}, 
      Alignment -> {-0.7, 0.7}] & )[
       DateListPlot[(countToGrowth[#1, rs] & ) /@ {totalCount, 
      gnuCount, marmaladeCount, melpaCount}, 
         PlotLabel -> 
     StringJoin["New packages since ", 
      DateString[rs, {"Day", " ", "MonthNameShort", " ", "Year"}]], 
    Joined -> True, 
         AxesStyle -> Directive[Thickness[0.004]], 
    DateTicksFormat -> {"Day", " ", "MonthNameShort"}, 
         GridLines -> {Join[({#1, Gray} & ) /@ 
        DateRange[rs, re, Quantity[DateDifference[rs, re]/40, "Day"]], 
               ({#1, Black} & ) /@ 
        DateRange[rs, re, 
         Quantity[DateDifference[rs, re]/4, "Day"]]], ({#1, 
          Gray} & ) /@ Array[5*#1 & , 200]}, 
         FrameTicks -> {Automatic, {DateRange[rs, re, 
        Quantity[DateDifference[rs, re]/4, "Day"]], None}}, 
    Method -> {"AxesInFront" -> False}]]; 
rangeStart = DatePlus[today, {{-1, "Month"}}]; 
newPackagePlotMonth = growthPlot[rangeStart, today]
newPackagePlotEver = growthPlot[totalCount[[1, 1]], today]
(Export[StringJoin[dataDir1, "newPackagePlotEver.", #1], 
     newPackagePlotEver, ImageSize -> 1000] & ) /@ {"pdf", "jpg", 
   "svg", "png"}; 
(Export[StringJoin[dataDir1, "newPackagePlotMonth.", #1], 
     newPackagePlotMonth, ImageSize -> 1000] & ) /@ {"pdf", "jpg", 
   "svg", "png"}; 
